RupayKg Minimal Backend

Deploy on Railway:
- Root directory: backend
- Start command:
  uvicorn main:app --host 0.0.0.0 --port $PORT
