
from fastapi import FastAPI, WebSocket, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pymongo import MongoClient
from datetime import datetime
import os

app = FastAPI(title="RupayKg Sovereign v4 - Government Simulation")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

client = MongoClient(os.getenv("MONGO_URI", "mongodb://localhost:27017"))
db = client["rupaykg_v4"]

@app.get("/health")
def health():
    return {"status": "ok", "version": "v4-gov-grade"}

@app.post("/waste/submit")
def submit_waste(data: dict):
    data["timestamp"] = str(datetime.utcnow())
    data["status"] = "pending_verification"
    db.waste.insert_one(data)
    return {"message": "Waste recorded", "state_id": data.get("state_id")}

@app.post("/waste/approve/{waste_id}")
def approve_waste(waste_id: str):
    db.waste.update_one({"_id": waste_id}, {"$set": {"status": "approved"}})
    return {"message": "Approved by authorized recycler"}

@app.get("/admin/state-metrics/{state_id}")
def state_metrics(state_id: str):
    count = db.waste.count_documents({"state_id": state_id})
    return {
        "state_id": state_id,
        "total_events": count,
        "carbon_estimate_tco2": round(count * 0.25, 2)
    }

@app.get("/carbon/registry-report/{state_id}")
def carbon_registry_report(state_id: str):
    return {
        "state_id": state_id,
        "article6_ready": True,
        "corresponding_adjustment": True,
        "report_generated_at": str(datetime.utcnow())
    }
