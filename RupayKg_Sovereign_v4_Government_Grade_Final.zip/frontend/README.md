
RupayKg Sovereign v4 Government Dashboard

Includes:
- State-level dashboards
- Carbon registry export simulation
- Article-6 export visualization
- Multi-tenant state routing ready
