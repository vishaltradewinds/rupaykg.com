
Upgradeable UUPS Contracts – Government Deployment Ready

Contracts:
- WasteProofUpgradeable.sol
- CarbonMintUpgradeable.sol
- CarbonCreditNFT.sol
- RupayKgGovernor.sol
- MultiSigControl.sol

Supports:
- Article-6 export schema anchoring
- State-node governance
- Timelock + DAO oversight
