
import axios from 'axios';
import {useEffect,useState} from 'react';

export default function GoLive(){
 const [data,setData]=useState(null);

 useEffect(()=>{
  axios.get(import.meta.env.VITE_API+"/go-live/status")
   .then(r=>setData(r.data));
 },[]);

 if(!data) return <div>Loading...</div>;

 return (
  <div>
   <h2>RupayKg Go-Live Checklist</h2>
   <ul>
    {Object.entries(data).map(([k,v])=>(
      <li key={k}>{k}: {v?"✅":"❌"}</li>
    ))}
   </ul>
   <h3>Status: {data.GO_LIVE_APPROVED?"GO-LIVE APPROVED":"HOLD"}</h3>
  </div>
 );
}
