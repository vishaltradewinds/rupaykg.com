
from jose import jwt
from datetime import datetime,timedelta
from config import JWT_SECRET

def sign(payload):
 payload["exp"]=datetime.utcnow()+timedelta(hours=8)
 return jwt.encode(payload,JWT_SECRET,algorithm="HS256")
