
from fastapi import FastAPI
from checks.golive import run_checks

app=FastAPI(title="RupayKg Go-Live Control Plane",version="1.0")

@app.get("/health")
def health():
 return {"status":"ok"}

@app.get("/go-live/status")
def golive():
 return run_checks()
