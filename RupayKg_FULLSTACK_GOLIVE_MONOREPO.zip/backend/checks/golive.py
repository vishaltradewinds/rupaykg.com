
from config import ENV,PAYOUTS_ENABLED,SYSTEM_LOCK
from ledger.ledger import ledger_status

def run_checks():
 results={}

 results["env_production"]=ENV=="production"
 results["payouts_disabled"]=PAYOUTS_ENABLED is False
 results["system_unlocked"]=SYSTEM_LOCK is False

 ledger=ledger_status()
 results["ledger_balanced"]=ledger["balanced"]

 results["GO_LIVE_APPROVED"]=all(results.values())
 return results
