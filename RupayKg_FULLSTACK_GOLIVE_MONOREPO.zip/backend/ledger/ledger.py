
from db import SessionLocal
def ledger_status():
 db=SessionLocal()
 credit=db.execute("SELECT SUM(amount) FROM ledger WHERE direction='CREDIT'").scalar() or 0
 debit=db.execute("SELECT SUM(amount) FROM ledger WHERE direction='DEBIT'").scalar() or 0
 return {"credit":credit,"debit":debit,"balanced":credit==debit}
