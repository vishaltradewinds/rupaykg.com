
from datetime import datetime
from db import SessionLocal
def log(actor,action):
 db=SessionLocal()
 db.execute("INSERT INTO audit_log (actor,action,ts) VALUES (:a,:ac,:ts)",
            {"a":actor,"ac":action,"ts":datetime.utcnow()})
 db.commit()
