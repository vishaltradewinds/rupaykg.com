from fastapi import Depends,HTTPException
from fastapi.security import HTTPBearer
from security.jwt import decode_jwt
security=HTTPBearer()
def require_role(*roles):
 def checker(token=Depends(security)):
  user=decode_jwt(token.credentials)
  if user.get("role") not in roles:
   raise HTTPException(403,"Forbidden")
  return user
 return checker
