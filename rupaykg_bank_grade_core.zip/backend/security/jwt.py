from jose import jwt,JWTError
from datetime import datetime,timedelta
from fastapi import HTTPException
from config import JWT_SECRET
def create_jwt(data):
 data["exp"]=datetime.utcnow()+timedelta(hours=8)
 return jwt.encode(data,JWT_SECRET,algorithm="HS256")
def decode_jwt(token):
 try:
  return jwt.decode(token,JWT_SECRET,algorithms=["HS256"])
 except JWTError:
  raise HTTPException(401,"Invalid token")
