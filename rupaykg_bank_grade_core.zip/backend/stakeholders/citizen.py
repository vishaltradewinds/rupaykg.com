from fastapi import APIRouter,Depends
from uuid import uuid4
from security.rbac import require_role
from ledger.double_entry import credit
from payments.payouts import request_payout
from audit.logger import audit
router=APIRouter(prefix="/citizen",tags=["Citizen"])

@router.post("/earn")
def earn(amount:float,user=Depends(require_role("CITIZEN"))):
 credit(user["sub"],amount)
 audit(user["sub"],"CITIZEN","EARN")
 return {"credited":amount}

@router.post("/payout-request")
def payout(amount:float,user=Depends(require_role("CITIZEN"))):
 status=request_payout(user["sub"],amount)
 audit(user["sub"],"CITIZEN","PAYOUT_REQUEST",status)
 return {"status":status}
