from datetime import datetime
from db import SessionLocal
def audit(actor,role,action,ref=None):
 db=SessionLocal()
 db.execute(
  "INSERT INTO audit_log (actor,role,action,ref,ts) VALUES (:a,:r,:ac,:ref,:ts)",
  {"a":actor,"r":role,"ac":action,"ref":ref,"ts":datetime.utcnow()}
 )
 db.commit()
