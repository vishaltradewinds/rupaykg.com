from config import PAYOUTS_ENABLED,SYSTEM_LOCK
from db import SessionLocal
def request_payout(user_id,amount):
 db=SessionLocal()
 status="BLOCKED"
 if PAYOUTS_ENABLED and not SYSTEM_LOCK:
  status="PENDING"
 db.execute(
  "INSERT INTO payout_requests (user_id,amount,status) VALUES (:u,:a,:s)",
  {"u":user_id,"a":amount,"s":status}
 )
 db.commit()
 return status
