from fastapi import FastAPI
from stakeholders import citizen
app=FastAPI(title="RupayKg Bank‑Grade Core",version="3.0")
app.include_router(citizen.router)
@app.get("/")
def health(): return {"status":"bank‑grade live"}
