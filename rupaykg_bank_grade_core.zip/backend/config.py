import os
ENV=os.getenv("ENV","production")
DATABASE_URL=os.getenv("DATABASE_URL")
JWT_SECRET=os.getenv("JWT_SECRET")
PAYOUTS_ENABLED=os.getenv("PAYOUTS_ENABLED","false").lower()=="true"
SYSTEM_LOCK=os.getenv("SYSTEM_LOCK","false").lower()=="true"
