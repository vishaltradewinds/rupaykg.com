from db import SessionLocal
import hashlib
def _hash(prev,account,amount,direction):
 raw=f"{prev}{account}{amount}{direction}".encode()
 return hashlib.sha256(raw).hexdigest()

def post_entry(account,amount,direction):
 db=SessionLocal()
 prev=db.execute("SELECT hash FROM ledger ORDER BY id DESC LIMIT 1").fetchone()
 prev_hash=prev[0] if prev else "GENESIS"
 h=_hash(prev_hash,account,amount,direction)
 db.execute(
  "INSERT INTO ledger (account,amount,direction,prev_hash,hash) VALUES (:a,:amt,:d,:p,:h)",
  {"a":account,"amt":amount,"d":direction,"p":prev_hash,"h":h}
 )
 db.commit()

def credit(account,amount):
 post_entry(account,amount,"CREDIT")
 post_entry("CSR_POOL",amount,"DEBIT")
