-- BANK‑GRADE LEDGER + AUDIT
CREATE TABLE IF NOT EXISTS ledger (
 id SERIAL PRIMARY KEY,
 account TEXT,
 amount NUMERIC,
 direction TEXT,
 prev_hash TEXT,
 hash TEXT,
 ts TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payout_requests (
 id SERIAL PRIMARY KEY,
 user_id TEXT,
 amount NUMERIC,
 status TEXT,
 ts TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_log (
 id SERIAL PRIMARY KEY,
 actor TEXT,
 role TEXT,
 action TEXT,
 ref TEXT,
 ts TIMESTAMP DEFAULT now()
);
