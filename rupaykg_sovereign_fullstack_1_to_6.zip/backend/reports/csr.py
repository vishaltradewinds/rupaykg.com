from fastapi import APIRouter
from db import SessionLocal
router=APIRouter(prefix='/reports/csr',tags=['CSR'])
@router.get('/summary')
def summary():
 db=SessionLocal()
 rows=db.execute("SELECT source, SUM(amount) FROM wallet_ledger GROUP BY source").fetchall()
 return {'summary':[{'source':r[0],'amount':float(r[1])} for r in rows]}
