CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY,
 role TEXT,
 created_at TIMESTAMP DEFAULT now()
);
CREATE TABLE IF NOT EXISTS consent_log (
 id SERIAL PRIMARY KEY,
 user_id TEXT,
 granted BOOLEAN,
 version TEXT,
 ts TIMESTAMP DEFAULT now()
);
CREATE TABLE IF NOT EXISTS waste_txn (
 id TEXT PRIMARY KEY,
 user_id TEXT,
 waste_type TEXT,
 weight NUMERIC,
 ts TIMESTAMP DEFAULT now()
);
CREATE TABLE IF NOT EXISTS wallet_ledger (
 id SERIAL PRIMARY KEY,
 user_id TEXT,
 amount NUMERIC,
 source TEXT,
 ref TEXT,
 ts TIMESTAMP DEFAULT now()
);
CREATE TABLE IF NOT EXISTS audit_log (
 id SERIAL PRIMARY KEY,
 actor TEXT,
 role TEXT,
 action TEXT,
 ref TEXT,
 ts TIMESTAMP DEFAULT now()
);
