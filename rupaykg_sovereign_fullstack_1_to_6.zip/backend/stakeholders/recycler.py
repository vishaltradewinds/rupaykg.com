from fastapi import APIRouter,Depends
from security.rbac import require_role
from audit.logger import audit_log
router=APIRouter(prefix='/recycler',tags=['Recycler'])
@router.post('/process')
def process(user=Depends(require_role('RECYCLER'))):
 audit_log(user['sub'],'RECYCLER','PROCESS_BATCH')
 return {'status':'processed'}
