
async function main() {
  const Waste = await ethers.getContractFactory("WasteProofUpgradeable");
  const waste = await upgrades.deployProxy(Waste, [process.env.ADMIN_ADDRESS], {
    initializer: "initialize",
    kind: "uups"
  });
  await waste.waitForDeployment();
  console.log("Waste Proxy:", await waste.getAddress());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
