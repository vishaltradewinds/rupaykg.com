
# RupayKg Sovereign-Grade Blockchain Module

Includes:
- UUPS Upgradeable WasteProof Contract
- DAO Governance (Governor + Timelock)
- Carbon Credit NFT
- Hardhat Deployment Scripts
- Polygon Deployment Ready
- Enterprise Merge Ready
