
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uuid

app = FastAPI(title="RupayKg ICM Regulator-Enforced Backend")

# In-memory store for demo
issuance_store = {}

class IssuanceRequest(BaseModel):
    verified_reduction: float
    dc_id: str

@app.post("/recommend-issuance")
def recommend_issuance(data: IssuanceRequest):
    issuance_id = str(uuid.uuid4())
    issuance_store[issuance_id] = {
        "verified_reduction": data.verified_reduction,
        "dc_id": data.dc_id,
        "regulator_approved": False,
        "registry_confirmed": False,
        "minted": False
    }
    return {"issuance_id": issuance_id, "status": "Pending Regulator Approval"}

@app.post("/regulator-approve/{issuance_id}")
def regulator_approve(issuance_id: str):
    if issuance_id not in issuance_store:
        raise HTTPException(status_code=404, detail="Issuance not found")
    issuance_store[issuance_id]["regulator_approved"] = True
    return {"status": "Regulator Approved"}

@app.post("/registry-confirm/{issuance_id}")
def registry_confirm(issuance_id: str):
    if issuance_id not in issuance_store:
        raise HTTPException(status_code=404, detail="Issuance not found")
    issuance_store[issuance_id]["registry_confirmed"] = True
    return {"status": "Registry Confirmed"}

@app.post("/mint/{issuance_id}")
def mint_credit(issuance_id: str):
    record = issuance_store.get(issuance_id)
    if not record:
        raise HTTPException(status_code=404, detail="Issuance not found")
    if not record["regulator_approved"]:
        raise HTTPException(status_code=403, detail="Regulator approval required")
    if not record["registry_confirmed"]:
        raise HTTPException(status_code=403, detail="Registry confirmation required")
    record["minted"] = True
    return {"status": "Carbon Credit Minted", "issuance_id": issuance_id}
