
Frontend Placeholder

Roles:
- Designated Consumer (submit data)
- Regulator (approve issuance)
- Registry (confirm issuance)
- Public Dashboard (view transparency)
