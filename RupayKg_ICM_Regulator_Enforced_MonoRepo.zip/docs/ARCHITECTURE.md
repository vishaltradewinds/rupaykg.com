
RupayKg ICM-Compliant Architecture

Key Principle:
No carbon credit can be minted without:
1. Regulator Approval
2. Registry Confirmation

Mint enforcement exists both:
- Backend level
- Smart contract level

RupayKg acts strictly as infrastructure layer.
