from fastapi import APIRouter
from auth import create_token

router = APIRouter()

@router.post("/login")
def login():
    return {"token": create_token({"role": "citizen"})}

@router.get("/wallet")
def wallet():
    return {"balance": 120.50}

@router.post("/pickup")
def pickup():
    return {"status": "Pickup recorded"}
