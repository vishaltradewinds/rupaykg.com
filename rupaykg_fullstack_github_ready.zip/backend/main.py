from fastapi import FastAPI
from routes import router

app = FastAPI(title="RupayKg Backend")

app.include_router(router)

@app.get("/")
def root():
    return {"status": "RupayKg Backend Live"}
