from jose import jwt
from datetime import datetime, timedelta
import os

SECRET = os.getenv("JWT_SECRET", "secret")

def create_token(data: dict):
    data["exp"] = datetime.utcnow() + timedelta(days=7)
    return jwt.encode(data, SECRET, algorithm="HS256")
