export default function Home() {
  return (
    <main style={{padding:40,fontFamily:'Arial'}}>
      <h1>RupayKg</h1>
      <p>Waste to Wealth Digital Platform</p>
      <button onClick={async()=>{
        const res = await fetch(process.env.NEXT_PUBLIC_API+'/wallet');
        alert(JSON.stringify(await res.json()));
      }}>Check Wallet</button>
    </main>
  );
}