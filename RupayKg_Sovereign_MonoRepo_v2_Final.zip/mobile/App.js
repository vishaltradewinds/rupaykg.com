
import { Text, View } from 'react-native';

export default function App() {
  return (
    <View>
      <Text>RupayKg Mobile Sovereign v2</Text>
    </View>
  );
}
