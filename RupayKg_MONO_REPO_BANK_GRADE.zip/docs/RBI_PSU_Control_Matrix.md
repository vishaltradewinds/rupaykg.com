
# RupayKg – Bank-Grade Control Matrix

## Identity & Access
- RBAC enforced
- MFA mandatory for admins
- No shared credentials

## Ledger Controls
- Double-entry ledger
- Hash-chained records
- Daily reconciliation

## Payment Controls
- Maker–checker enforced
- Policy-gated execution
- Sponsor bank integration only

## Operational Controls
- Emergency system lock
- Read-only fail-safe mode

## Audit & Compliance
- Immutable logs
- SIEM integration
- Encrypted backups
