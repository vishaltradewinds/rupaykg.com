
# Audit Test Scenarios

## Ledger Integrity
- Attempt manual update → FAIL
- Verify hash-chain continuity → PASS

## Payout Controls
- Citizen direct payout → BLOCKED
- Admin without checker → BLOCKED

## Security
- Expired JWT → REJECTED
- Role escalation attempt → REJECTED

## DR & Recovery
- Restore from encrypted backup → PASS
