
# RupayKg – Unified Sovereign & Bank-Grade Mono-Repo

This mono-repo is a **single runnable codebase** consolidating:
- Bank-grade double-entry ledger
- Maker–checker payouts (policy gated)
- Sovereign waste + MRV logic
- Municipal & CSR dashboards
- Article-6 reporting
- HSM, SIEM, DR stubs
- Audit & compliance documentation

## Run backend (VPS / Docker)
cd backend
docker build -t rupaykg .
docker run -p 8000:8000 \
 -e DATABASE_URL=postgresql://user:pass@host:5432/rupaykg \
 -e JWT_SECRET=long_secret \
 -e PAYOUTS_ENABLED=false \
 -e SYSTEM_LOCK=false \
 rupaykg

Swagger: http://localhost:8000/docs

## Frontend dashboards
cd frontend
npm install
npm run dev
