
from db import SessionLocal

def reconcile():
    db = SessionLocal()
    credits = db.execute("SELECT SUM(amount) FROM ledger WHERE direction='CREDIT'").scalar() or 0
    debits = db.execute("SELECT SUM(amount) FROM ledger WHERE direction='DEBIT'").scalar() or 0
    if credits != debits:
        raise Exception("Ledger imbalance detected")
    return {"status":"OK","credits":credits,"debits":debits}
