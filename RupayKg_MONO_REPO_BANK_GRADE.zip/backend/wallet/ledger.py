from db import SessionLocal

def credit(user_id,amount,source,ref):
 db=SessionLocal()
 db.execute("INSERT INTO wallet_ledger (user_id,amount,source,ref) VALUES (:u,:a,:s,:r)",{'u':user_id,'a':amount,'s':source,'r':ref})
 db.commit()
