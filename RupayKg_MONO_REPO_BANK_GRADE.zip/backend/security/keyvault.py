
# HSM / External Key Vault Stub
# Replace with actual HSM client (CloudHSM, Thales, NIC HSM)

def sign_jwt(payload):
    # payload signing delegated to external vault
    raise NotImplementedError("HSM integration required")
