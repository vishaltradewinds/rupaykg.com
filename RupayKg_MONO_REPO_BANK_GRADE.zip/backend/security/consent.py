from fastapi import HTTPException
from db import SessionLocal

def require_consent(user_id):
 db=SessionLocal()
 res=db.execute("SELECT granted FROM consent_log WHERE user_id=:u ORDER BY ts DESC LIMIT 1",{'u':user_id}).fetchone()
 if not res or not res[0]:
  raise HTTPException(403,'Consent not granted')
