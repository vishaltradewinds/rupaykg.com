from fastapi import APIRouter,Depends
from uuid import uuid4
from security.rbac import require_role
from wallet.ledger import credit
from waste.valuation import calculate_value
from audit.logger import audit_log
router=APIRouter(prefix='/citizen',tags=['Citizen'])
@router.post('/submit-waste')
def submit_waste(weight:float,user=Depends(require_role('CITIZEN'))):
 value=calculate_value(weight)
 ref=str(uuid4())
 credit(user['sub'],value,'CSR',ref)
 audit_log(user['sub'],'CITIZEN','SUBMIT_WASTE',ref)
 return {'credited':value,'ref':ref}
