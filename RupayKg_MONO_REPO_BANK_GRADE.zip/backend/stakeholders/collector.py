from fastapi import APIRouter,Depends
from security.rbac import require_role
from audit.logger import audit_log
router=APIRouter(prefix='/collector',tags=['Collector'])
@router.post('/confirm')
def confirm(user=Depends(require_role('COLLECTOR'))):
 audit_log(user['sub'],'COLLECTOR','CONFIRM_PICKUP')
 return {'status':'confirmed'}
