
import json, datetime

def emit(event_type, payload):
    record = {
        "event": event_type,
        "payload": payload,
        "ts": datetime.datetime.utcnow().isoformat()
    }
    # Forward to SIEM (Splunk / ELK / Govt SOC)
    print(json.dumps(record))
