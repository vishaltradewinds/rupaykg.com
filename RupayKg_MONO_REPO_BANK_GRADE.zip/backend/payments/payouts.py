from config import PAYOUTS_ENABLED
from db import SessionLocal

def request_payout(user_id,amount,method):
 db=SessionLocal()
 status='PENDING' if PAYOUTS_ENABLED else 'BLOCKED'
 db.execute(
  "INSERT INTO payout_requests (user_id,amount,method,status) VALUES (:u,:a,:m,:s)",
  {'u':user_id,'a':amount,'m':method,'s':status}
 )
 db.commit()
 return status
