
# Sponsor Bank / PSP Contract Stub
# RupayKg sends signed payout instructions only

def send_instruction(payout_id, amount, vpa):
    return {
        "payout_id": payout_id,
        "status": "RECEIVED_BY_BANK",
        "rail": "UPI"
    }
