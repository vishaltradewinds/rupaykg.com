from fastapi import FastAPI
from stakeholders import citizen
app=FastAPI(title='RupayKg Sovereign Backend',version='1.0')
app.include_router(citizen.router)
@app.get('/')
def health(): return {'status':'live'}
