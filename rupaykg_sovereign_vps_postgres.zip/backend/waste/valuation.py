def calculate_value(weight):
 return min(weight*2,500)
