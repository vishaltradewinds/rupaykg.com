export default function Home() {
  return (
    <main style={{ fontFamily: "sans-serif", padding: "2rem" }}>
      <h1>RuPayKG Wallet</h1>
      <p>Visit <a href="/wallet">/wallet</a> to view your wallet dashboard.</p>
    </main>
  );
}
