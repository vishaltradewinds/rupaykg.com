# RupayKG Enterprise

## Deploying the website to Vercel

This repository now includes a Vercel configuration for deploying the Next.js frontend from `frontend/`.

### 1) Install dependencies locally

```bash
cd frontend
npm install
```

### 2) Run a local production build check

```bash
npm run build
```

### 3) Deploy with Vercel CLI

From the repository root:

```bash
npx vercel --prod
```

When prompted:
- Set the project root to `./` (the included `vercel.json` handles building `frontend/package.json`).
- Add `NEXT_PUBLIC_API_URL` to your Vercel environment variables (for example your backend URL).

### 4) Optional: pull Vercel env vars locally

```bash
npx vercel env pull frontend/.env.local
```

Then run:

```bash
cd frontend
npm run dev
```
