from fastapi import FastAPI
from stakeholders import citizen,municipal
from reports import csr
app=FastAPI(title='RupayKg Sovereign Infrastructure',version='1.1')
app.include_router(citizen.router)
app.include_router(municipal.router)
app.include_router(csr.router)
@app.get('/')
def health(): return {'status':'live'}
