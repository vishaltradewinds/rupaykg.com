from fastapi import APIRouter,Depends
from security.rbac import require_role
from db import SessionLocal
router=APIRouter(prefix='/municipal',tags=['Municipal'])
@router.get('/ward-analytics')
def ward_analytics(user=Depends(require_role('MUNICIPAL','ADMIN'))):
 db=SessionLocal()
 rows=db.execute(
  "SELECT ward, SUM(weight) FROM waste_txn GROUP BY ward"
 ).fetchall()
 return {'wards':[{'ward':r[0],'total_weight':float(r[1])} for r in rows]}
