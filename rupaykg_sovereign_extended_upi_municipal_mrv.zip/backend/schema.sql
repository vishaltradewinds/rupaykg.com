CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY,
 role TEXT,
 ward TEXT,
 created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS consent_log (
 id SERIAL PRIMARY KEY,
 user_id TEXT,
 granted BOOLEAN,
 version TEXT,
 ts TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS waste_txn (
 id TEXT PRIMARY KEY,
 user_id TEXT,
 ward TEXT,
 waste_type TEXT,
 weight NUMERIC,
 ts TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS wallet_ledger (
 id SERIAL PRIMARY KEY,
 user_id TEXT,
 amount NUMERIC,
 source TEXT,
 ref TEXT,
 ts TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payout_requests (
 id SERIAL PRIMARY KEY,
 user_id TEXT,
 amount NUMERIC,
 method TEXT,
 status TEXT DEFAULT 'BLOCKED',
 ts TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_log (
 id SERIAL PRIMARY KEY,
 actor TEXT,
 role TEXT,
 action TEXT,
 ref TEXT,
 ts TIMESTAMP DEFAULT now()
);

-- Article 6 / MRV
CREATE TABLE IF NOT EXISTS mitigation_records (
 id TEXT PRIMARY KEY,
 waste_txn_id TEXT,
 methodology TEXT,
 co2e NUMERIC,
 jurisdiction TEXT,
 ts TIMESTAMP DEFAULT now()
);
