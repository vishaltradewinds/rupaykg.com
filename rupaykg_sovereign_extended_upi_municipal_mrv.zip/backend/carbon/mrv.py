from uuid import uuid4
from db import SessionLocal

def record_mitigation(waste_txn_id,methodology,co2e,jurisdiction):
 db=SessionLocal()
 mid=str(uuid4())
 db.execute(
  "INSERT INTO mitigation_records (id,waste_txn_id,methodology,co2e,jurisdiction)"
  " VALUES (:i,:w,:m,:c,:j)",
  {'i':mid,'w':waste_txn_id,'m':methodology,'c':co2e,'j':jurisdiction}
 )
 db.commit()
 return mid
