from datetime import datetime
from db import db

async def log(action,actor,role,ref=None):
 await db.audit.insert_one({'action':action,'actor':actor,'role':role,'ref':ref,'ts':datetime.utcnow()})
