import os

ENV=os.getenv('ENV','demo')
JWT_SECRET=os.getenv('JWT_SECRET','demo_secret')
MONGO_URI=os.getenv('MONGO_URI')
DEMO_MODE=ENV=='demo'
