from fastapi import APIRouter,Depends
from rbac import require_role
from audit import log
router=APIRouter(prefix='/collector',tags=['Collector'])
@router.post('/confirm-pickup')
async def confirm(user=Depends(require_role('COLLECTOR'))):
 await log('CONFIRM_PICKUP',user['sub'],user['role'])
 return {'status':'pickup verified'}
