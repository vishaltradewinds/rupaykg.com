from fastapi import APIRouter,Depends
from rbac import require_role
from audit import log
from wallet import credit
router=APIRouter(prefix='/citizen',tags=['Citizen'])
@router.post('/pickup-request')
async def pickup(user=Depends(require_role('CITIZEN'))):
 await log('PICKUP_REQUEST',user['sub'],user['role'])
 await credit(user['sub'],150)
 return {'status':'pickup recorded','credit':150}
@router.get('/wallet')
async def wallet(user=Depends(require_role('CITIZEN'))): return {'balance':150,'currency':'INR'}
