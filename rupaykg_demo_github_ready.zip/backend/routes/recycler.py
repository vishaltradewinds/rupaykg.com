from fastapi import APIRouter,Depends
from rbac import require_role
from audit import log
router=APIRouter(prefix='/recycler',tags=['Recycler'])
@router.post('/confirm-receipt')
async def receipt(user=Depends(require_role('RECYCLER'))):
 await log('RECEIPT_CONFIRMED',user['sub'],user['role'])
 return {'status':'batch received'}
