from fastapi import APIRouter,Depends
from rbac import require_role
router=APIRouter(prefix='/admin',tags=['Admin'])
@router.get('/audit-log')
async def audit(user=Depends(require_role('ADMIN'))): return {'status':'audit access granted'}
