from jose import jwt,JWTError
from datetime import datetime,timedelta
from fastapi import Depends,HTTPException
from fastapi.security import HTTPBearer
from config import JWT_SECRET
security=HTTPBearer()

def create_token(user_id,role,consent=True):
 payload={'sub':user_id,'role':role,'consent':consent,'exp':datetime.utcnow()+timedelta(days=7)}
 return jwt.encode(payload,JWT_SECRET,algorithm='HS256')

def get_current_user(token=Depends(security)):
 try:
  return jwt.decode(token.credentials,JWT_SECRET,algorithms=['HS256'])
 except JWTError:
  raise HTTPException(401,'Invalid token')
