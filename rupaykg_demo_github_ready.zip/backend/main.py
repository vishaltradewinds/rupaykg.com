from fastapi import FastAPI
from routes import citizen,collector,recycler,admin
app=FastAPI(title='RupayKg Demo API',version='1.0')
app.include_router(citizen.router)
app.include_router(collector.router)
app.include_router(recycler.router)
app.include_router(admin.router)
@app.get('/')
def root(): return {'status':'RupayKg Demo Backend Live'}
