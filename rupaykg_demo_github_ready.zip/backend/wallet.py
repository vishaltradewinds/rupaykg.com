from db import db
from config import DEMO_MODE

async def credit(user_id,amount,source='demo'):
 if DEMO_MODE:
  amount=min(amount,200)
 await db.wallet.update_one({'user_id':user_id},{'$inc':{'balance':amount}},upsert=True)
